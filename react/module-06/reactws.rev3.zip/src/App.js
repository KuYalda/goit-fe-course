import React from 'react';

const App = () => <></>;

export default App;
